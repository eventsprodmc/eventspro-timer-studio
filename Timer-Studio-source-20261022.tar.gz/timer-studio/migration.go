package main

import (
	"encoding/binary"
	"encoding/json"
	"github.com/syndtr/goleveldb/leveldb"
	"github.com/syndtr/goleveldb/leveldb/opt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"time"
	"unicode/utf16"
)

func decodeStorage(b []byte) string {
	if len(b) == 0 {
		return ""
	}
	if b[0] == 1 {
		runes := make([]rune, len(b)-1)
		for i, v := range b[1:] {
			runes[i] = rune(v)
		}
		return string(runes)
	}
	if b[0] == 0 {
		u := []uint16{}
		for i := 1; i+1 < len(b); i += 2 {
			u = append(u, binary.LittleEndian.Uint16(b[i:]))
		}
		return string(utf16.Decode(u))
	}
	return ""
}
func legacyData() map[string]string {
	base, _ := os.UserConfigDir()
	if runtime.GOOS == "windows" {
		base = os.Getenv("APPDATA")
	}
	root := filepath.Join(base, "EventsPRO")
	cache := filepath.Join(root, "Timer Studio Lightweight", "migration.json")
	if b, e := os.ReadFile(cache); e == nil {
		var saved struct {
			Schema int               `json:"schema"`
			Data   map[string]string `json:"data"`
		}
		if json.Unmarshal(b, &saved) == nil && saved.Schema == 2 {
			return saved.Data
		}
	}
	old := filepath.Join(root, "Timer Studio", "Partitions", "eventspro-timer", "Local Storage", "leveldb")
	if _, e := os.Stat(filepath.Join(old, "CURRENT")); e != nil {
		return nil
	}
	backup := filepath.Join(root, "Timer Studio backups", "electron-"+time.Now().Format("20060102-150405"))
	if e := os.MkdirAll(backup, 0700); e != nil {
		return nil
	}
	e := filepath.WalkDir(old, func(path string, d os.DirEntry, e error) error {
		if e != nil {
			return e
		}
		rel, _ := filepath.Rel(old, path)
		dest := filepath.Join(backup, rel)
		if d.IsDir() {
			return os.MkdirAll(dest, 0700)
		}
		src, e := os.Open(path)
		if e != nil {
			return e
		}
		defer src.Close()
		out, e := os.OpenFile(dest, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if e != nil {
			return e
		}
		_, e = io.Copy(out, src)
		out.Close()
		return e
	})
	if e != nil {
		return nil
	}
	db, e := leveldb.OpenFile(backup, &opt.Options{ReadOnly: true})
	if e != nil {
		return nil
	}
	defer db.Close()
	data := map[string]string{}
	it := db.NewIterator(nil, nil)
	for it.Next() {
		key := string(it.Key())
		prefix := "_https://tools.eventspro.es\x00"
		if !strings.HasPrefix(key, prefix) {
			continue
		}
		name := decodeStorage([]byte(key[len(prefix):]))
		if name != "eventspro-speaker-timer-v1" && name != "eventspro-speaker-timer-v1-presets" && name != "eventspro-speaker-timer-v1-messages" {
			continue
		}
		value := decodeStorage(it.Value())
		if json.Valid([]byte(value)) {
			data[name] = value
		}
	}
	it.Release()
	if len(data) > 0 {
		if e := os.MkdirAll(filepath.Dir(cache), 0700); e == nil {
			b, _ := json.Marshal(map[string]any{"schema": 2, "data": data})
			if old, e := os.ReadFile(cache); e == nil {
				if e = os.WriteFile(cache+time.Now().Format(".backup-20060102-150405"), old, 0600); e != nil {
					return data
				}
			}
			os.WriteFile(cache, b, 0600)
		}
	}
	return data
}
