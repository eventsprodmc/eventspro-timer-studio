# EventsPRO Timer Studio

Standalone source for Timer Studio: countdown, speaker display, agenda presets, Companion OSC and phone remote on a local network.

## Scope and licence

Only the files in this repository are published. EventsPRO-owned code here is licensed under MIT; third-party components retain their own licences. This does not license, publish or transfer the rest of the EventsPRO TOOLS suite, its catalogues, manuals or other applications. Generic project/menu helpers included here are copies used by Timer. EventsPRO names and logos identify the project; no trademark rights are granted by this licence.

The existing hosted suite and Mac release are not changed by this source publication.

## Build and test

Requires Go 1.25 or later. Run `go test ./...`. Build Windows x64 with:

```
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-s -w -H windowsgui" -o build/Timer-Studio.exe .
```

Windows requires Microsoft Edge WebView2 Runtime installed. The standard WebView2Loader.dll from `third_party/go-webview2/webviewloader/sdk/x64/` must accompany the executable. The SDK redistributable is covered by its included Microsoft licence, not MIT. A runtime installation may require internet; subsequent Timer local-network control does not use a cloud relay.

The `web/` directory contains editable Timer resources and their URL mapping. Run `python3 scripts/rebuild-assets.py` after editing them, before building. Native mobile assets are in `assets/`.

## Local operation and privacy

Timer listens on HTTP port 9140 and OSC UDP port 9010. The computer displays the pairing QR; the phone scans it. Pairing uses a random token and the local network. Remote status uses device family and LAN IP. Browser/project data stays on the computer unless the user exports it. Local HTTP is not encrypted: use a trusted event network. Opening external links is optional and requires internet.

## Release and signing status

This source release is not a signed Windows release. Free signing eligibility is under preparation; no signing service approval is claimed. Chrome/SmartScreen acceptance and installation on Windows still require testing. Do not disable endpoint protection to run a build.

## Third-party components

* qrcode-generator 2.0.4: MIT, notice retained in its JavaScript source.
* jsQR 1.4.0: Apache-2.0, see `licenses/jsQR-Apache-2.0.txt`.
* Go dependencies: see `licenses/Go-dependencies.txt` and module licences.
* go-webview2: vendored MIT fork, see `UPSTREAM.md`.
* Microsoft WebView2 loader: SDK licence included alongside its binaries.
