package main

import (
	"bytes"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

// Real TCP sockets and commands, without any hosting service.
func TestOfficeMobileTCPCommandsAndAcknowledgement(t *testing.T) {
	r, e := startReceiver(0)
	if e != nil {
		t.Fatal(e)
	}
	defer r.close()
	r.syncState(sampleState())
	token := strings.Repeat("a", 64)
	s := httptest.NewUnstartedServer(nil)
	s.Config.Handler = serveTimer(r, token, s.Listener.Addr().(*net.TCPAddr).Port)
	s.Start()
	defer s.Close()
	for _, path := range []string{"/mobile.html", "/timer-mobile-remote.js"} {
		res, e := s.Client().Get(s.URL + path)
		if e != nil {
			t.Fatal(e)
		}
		b, _ := io.ReadAll(res.Body)
		res.Body.Close()
		if res.StatusCode != 200 || len(b) == 0 {
			t.Fatal(path, res.StatusCode)
		}
		if path == "/mobile.html" && bytes.Contains(b, []byte("https://")) {
			t.Fatal("internet dependency")
		}
	}
	post := func(control, op string, cmd map[string]any) int {
		b, _ := json.Marshal(map[string]any{"control": control, "op": op, "command": cmd})
		q, _ := http.NewRequest("POST", s.URL+"/mobile/sync", bytes.NewReader(b))
		q.Header.Set("Origin", s.URL)
		q.Header.Set("Content-Type", "application/json")
		res, e := s.Client().Do(q)
		if e != nil {
			t.Fatal(e)
		}
		io.Copy(io.Discard, res.Body)
		res.Body.Close()
		return res.StatusCode
	}
	if post("wrong", "read", nil) != 401 {
		t.Fatal("invalid token accepted")
	}
	for _, cmd := range []map[string]any{{"action": "start"}, {"action": "pause"}, {"action": "reset"}, {"action": "adjust", "value": float64(60)}, {"action": "preset", "value": "manuel"}, {"action": "message/preset", "value": "aviso"}} {
		if post(token, "command", cmd) != 200 {
			t.Fatal(cmd)
		}
		state := sampleState()
		out, _ := r.syncState(state)
		q := out["data"].(map[string]any)["commands"].([]command)
		if len(q) != 1 || q[0].Action != cmd["action"] {
			t.Fatal(q)
		}
		state["ack"] = []any{float64(q[0].ID)}
		out, _ = r.syncState(state)
		if len(out["data"].(map[string]any)["commands"].([]command)) != 0 {
			t.Fatal("ack failed")
		}
	}
	if post(token, "read", nil) != 200 {
		t.Fatal("feedback failed")
	}
}
