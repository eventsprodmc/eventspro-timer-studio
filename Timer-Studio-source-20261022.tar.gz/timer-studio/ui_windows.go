package main

import (
	webview "github.com/jchv/go-webview2"
	"os"
	"path/filepath"
	"runtime"
	"sync"
	"syscall"
	"unicode/utf16"
	"unsafe"
)

var user32 = syscall.NewLazyDLL("user32.dll")
var comdlg = syscall.NewLazyDLL("comdlg32.dll")
var shell32 = syscall.NewLazyDLL("shell32.dll")
var speakerLock sync.Mutex

func utf(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func newView() view {
	dpi := user32.NewProc("SetProcessDpiAwarenessContext")
	if dpi.Find() == nil {
		dpi.Call(^uintptr(3))
	}
	profile := filepath.Join(os.Getenv("LOCALAPPDATA"), "EventsPRO", "Timer Studio", "WebView2")
	return webview.NewWithOptions(webview.WebViewOptions{DataPath: profile, AutoFocus: true, WindowOptions: webview.WindowOptions{IconId: 1}})
}
func configureMain(w unsafe.Pointer) {
	id := utf("EventsPRO.TimerStudio")
	shell32.NewProc("SetCurrentProcessExplicitAppUserModelID").Call(uintptr(unsafe.Pointer(id)))
	mainView.(webview.WebView).SetSize(1440, 1000, webview.HintNone)
	mainView.(webview.WebView).SetSize(800, 600, webview.HintMin)
}

type rect struct{ Left, Top, Right, Bottom int32 }
type monitorInfo struct {
	Size          uint32
	Monitor, Work rect
	Flags         uint32
}

func externalRect(main unsafe.Pointer) (rect, bool) {
	current, _, _ := user32.NewProc("MonitorFromWindow").Call(uintptr(main), 2)
	var result rect
	found := false
	cb := syscall.NewCallback(func(mon, hdc, r, data uintptr) uintptr {
		if mon != current {
			var info monitorInfo
			info.Size = uint32(unsafe.Sizeof(info))
			ok, _, _ := user32.NewProc("GetMonitorInfoW").Call(mon, uintptr(unsafe.Pointer(&info)))
			if ok != 0 {
				result = info.Monitor
				found = true
				return 0
			}
		}
		return 1
	})
	user32.NewProc("EnumDisplayMonitors").Call(0, 0, cb, 0)
	return result, found
}
func hasExternal(w unsafe.Pointer) bool { _, ok := externalRect(w); return ok }
func configureSpeaker(w, main unsafe.Pointer) {
	r, ok := externalRect(main)
	if !ok {
		return
	}
	user32.NewProc("SetWindowLongPtrW").Call(uintptr(w), ^uintptr(15), 0x80000000|0x10000000)
	user32.NewProc("SetWindowPos").Call(uintptr(w), ^uintptr(0), uintptr(r.Left), uintptr(r.Top), uintptr(r.Right-r.Left), uintptr(r.Bottom-r.Top), 0x0020|0x0040)
}
func toggleSpeaker(url string) map[string]any {
	speakerLock.Lock()
	defer speakerLock.Unlock()
	if speakerView != nil {
		w := speakerView
		speakerView = nil
		w.Dispatch(func() { w.Terminate() })
		return map[string]any{"open": false}
	}
	if !hasExternal(mainView.Window()) {
		return map[string]any{"open": false, "error": "single"}
	}
	ch := make(chan view, 1)
	go func() {
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()
		w := newView()
		if w == nil {
			ch <- nil
			return
		}
		w.SetTitle("Timer Studio · Escenario")
		configureSpeaker(w.Window(), mainView.Window())
		w.Navigate(url)
		ch <- w
		w.Run()
		w.Destroy()
		speakerLock.Lock()
		if speakerView == w {
			speakerView = nil
		}
		speakerLock.Unlock()
	}()
	speakerView = <-ch
	if speakerView == nil {
		return map[string]any{"open": false, "error": "load"}
	}
	return map[string]any{"open": true}
}
func closeSpeaker() {
	speakerLock.Lock()
	defer speakerLock.Unlock()
	if speakerView != nil {
		w := speakerView
		speakerView = nil
		w.Dispatch(func() { w.Terminate() })
	}
}

type openFileName struct {
	Size                         uint32
	Owner, Instance              uintptr
	Filter, CustomFilter         *uint16
	MaxCustomFilter, FilterIndex uint32
	File                         *uint16
	MaxFile                      uint32
	FileTitle                    *uint16
	MaxFileTitle                 uint32
	InitialDir, Title            *uint16
	Flags                        uint32
	FileOffset, FileExtension    uint16
	DefaultExt                   *uint16
	CustomData                   uintptr
	Hook                         uintptr
	Template                     *uint16
	Reserved                     uintptr
	Reserved2, FlagsEx           uint32
}

func fileDialog(save bool, name string) string {
	buf := make([]uint16, 32768)
	copy(buf, syscall.StringToUTF16(name))
	filter := utf16.Encode([]rune("Proyecto Timer (*.json;*.csv)\x00*.json;*.csv\x00Todos los archivos\x00*.*\x00\x00"))
	ofn := openFileName{Owner: uintptr(mainView.Window()), Filter: &filter[0], File: &buf[0], MaxFile: uint32(len(buf)), Flags: 0x00080000 | 0x00000008 | 0x00001000}
	ofn.Size = uint32(unsafe.Sizeof(ofn))
	proc := "GetOpenFileNameW"
	if save {
		proc = "GetSaveFileNameW"
		ofn.Flags = 0x00080000 | 0x00000008 | 0x00000002
		ofn.DefaultExt = utf("json")
	}
	ok, _, _ := comdlg.NewProc(proc).Call(uintptr(unsafe.Pointer(&ofn)))
	if ok == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf)
}
func openDialog() string            { return fileDialog(false, "") }
func saveDialog(name string) string { return fileDialog(true, name) }
func showError(text string) {
	user32.NewProc("MessageBoxW").Call(0, uintptr(unsafe.Pointer(utf(text))), uintptr(unsafe.Pointer(utf("Timer Studio"))), 0x10)
}
func openExternal(url string) {
	shell32.NewProc("ShellExecuteW").Call(0, uintptr(unsafe.Pointer(utf("open"))), uintptr(unsafe.Pointer(utf(url))), 0, 0, 1)
}
