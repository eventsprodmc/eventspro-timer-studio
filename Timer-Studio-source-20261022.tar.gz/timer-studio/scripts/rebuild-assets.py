from pathlib import Path
import json, hashlib
root=Path(__file__).resolve().parents[1]
index=json.loads((root/'web/resources.json').read_text())
m={}
for url,name in index.items():
    b=(root/'web'/name).read_bytes()
    h=hashlib.sha256(b).hexdigest()
    (root/'assets/snapshot/blobs'/h).write_bytes(b)
    m[url]=h
(root/'assets/snapshot/map.json').write_text(json.dumps(m,indent=2)+'\n')
