package main

import (
	"crypto/rand"
	"crypto/subtle"
	"embed"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"mime"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"time"
	"unsafe"
)

//go:embed assets
var assets embed.FS

type view interface {
	Run()
	Terminate()
	Dispatch(func())
	Destroy()
	Window() unsafe.Pointer
	SetTitle(string)
	Navigate(string)
	Init(string)
	Eval(string)
	Bind(string, any) error
}

var mainView, speakerView view
var snapshot map[string]string

func addresses() []string {
	out := []string{}
	a, _ := net.InterfaceAddrs()
	for _, v := range a {
		if n, ok := v.(*net.IPNet); ok {
			ip := n.IP.To4()
			if ip != nil && !ip.IsLoopback() && !ip.IsLinkLocalUnicast() {
				out = append(out, ip.String())
			}
		}
	}
	return out
}
func main() {
	runtime.LockOSThread()
	b, _ := assets.ReadFile("assets/snapshot/map.json")
	if e := json.Unmarshal(b, &snapshot); e != nil {
		panic(e)
	}
	port := 9010
	httpPort := 9140
	if os.Getenv("EVENTSPRO_TIMER_LIGHT_TEST") == "1" {
		port = 19010
		httpPort = 19140
	}
	r, e := startReceiver(port)
	if e != nil {
		showError("El puerto de Timer está ocupado. Cierra la otra ventana de Timer.")
		return
	}
	defer r.close()
	tokenBytes := make([]byte, 32)
	rand.Read(tokenBytes)
	token := hex.EncodeToString(tokenBytes)
	listener, e := net.Listen("tcp4", fmt.Sprint("0.0.0.0:", httpPort))
	if e != nil {
		showError("El puerto de control móvil está ocupado.")
		return
	}
	defer listener.Close()
	mobileURL := func() string {
		a := addresses()
		if len(a) == 0 {
			return ""
		}
		return fmt.Sprintf("http://%s:%d/mobile.html#timer-remote=%s", a[0], httpPort, token)
	}
	server := &http.Server{Handler: serveTimer(r, token, httpPort), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 5 * time.Second, WriteTimeout: 10 * time.Second, MaxHeaderBytes: 16384}
	go func() {
		if e := server.Serve(listener); e != nil && !errors.Is(e, http.ErrServerClosed) {
			log.Print(e)
		}
	}()
	defer server.Close()
	mainView = newView()
	if mainView == nil {
		showError("No se ha podido abrir el motor web del sistema.")
		return
	}
	defer mainView.Destroy()
	mainView.SetTitle("Timer Studio · Tools EventsPRO")
	configureMain(mainView.Window())
	mainView.Bind("timerNativeMobileStatus", func() map[string]any { return r.mobileStatus() })
	mainView.Bind("timerNativeMobileURL", func() string { return mobileURL() })
	mainView.Bind("timerNativeSync", func(p map[string]any) (map[string]any, error) {
		v, e := r.syncState(p)
		if e == nil {
			v["data"].(map[string]any)["mobileUrl"] = mobileURL()
		}
		return v, e
	})
	mainView.Bind("timerNativeSpeaker", func() (map[string]any, error) {
		return toggleSpeaker(fmt.Sprintf("http://127.0.0.1:%d/timer-output-v19.html?nativeSpeaker=1", httpPort)), nil
	})
	mainView.Bind("timerNativeSave", func(name, encoded string) (bool, error) {
		data, e := base64.StdEncoding.DecodeString(encoded)
		if e != nil || len(data) > 100*1024*1024 {
			return false, errors.New("Invalid file")
		}
		path := saveDialog(filepath.Base(name))
		if path == "" {
			return false, nil
		}
		if existing, e := os.ReadFile(path); e == nil {
			backup := path + time.Now().Format(".backup-20060102-150405")
			if e = os.WriteFile(backup, existing, 0600); e != nil {
				return false, e
			}
		}
		return true, os.WriteFile(path, data, 0600)
	})
	mainView.Bind("timerNativeOpen", func() (map[string]string, error) {
		path := openDialog()
		if path == "" {
			return nil, nil
		}
		b, e := os.ReadFile(path)
		if e != nil {
			return nil, e
		}
		if len(b) > 100*1024*1024 {
			return nil, errors.New("File too large")
		}
		return map[string]string{"name": filepath.Base(path), "data": base64.StdEncoding.EncodeToString(b)}, nil
	})
	mainView.Bind("timerNativeExternal", func(raw string) bool {
		u, e := url.Parse(raw)
		if e != nil {
			return false
		}
		ip := net.ParseIP(u.Hostname())
		if u.Scheme == "https" || (u.Scheme == "http" && ip != nil && localPeer(ip) && u.Port() == "8000") {
			openExternal(raw)
			return true
		}
		return false
	})
	legacy, _ := json.Marshal(legacyData())
	mainView.Init("(()=>{const data=" + string(legacy) + ";if(data&&!localStorage.getItem('eventspro-speaker-timer-v1')){for(const [k,v]of Object.entries(data))localStorage.setItem(k,v);}})();")
	bridge, _ := assets.ReadFile("assets/bridge.js")
	mainView.Init(string(bridge))
	mainView.Navigate(fmt.Sprintf("http://127.0.0.1:%d/timer.html", httpPort))
	mainView.Run()
	closeSpeaker()
}

func serveTimer(r *receiver, token string, port int) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, q *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		host, _, e := net.SplitHostPort(q.RemoteAddr)
		if e != nil || !localPeer(net.ParseIP(host)) {
			http.Error(w, "Forbidden", 403)
			return
		}
		validHost := q.Host == fmt.Sprintf("127.0.0.1:%d", port)
		for _, ip := range addresses() {
			validHost = validHost || q.Host == fmt.Sprintf("%s:%d", ip, port)
		}
		if !validHost {
			http.Error(w, "Forbidden", 403)
			return
		}
		route := q.URL.Path
		mobile := route == "/" || route == "/mobile.html" || route == "/timer-mobile-remote.js" || route == "/mobile/sync"
		if !mobile && !net.ParseIP(host).IsLoopback() {
			http.Error(w, "Forbidden", 403)
			return
		}
		if mobile {
			w.Header().Set("Content-Security-Policy", "default-src 'none'; script-src 'self'; connect-src 'self'; style-src 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
		}
		if q.Method == "GET" && (route == "/" || route == "/mobile.html") {
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			io.WriteString(w, "<!doctype html><html lang=es><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>Timer Studio · Control móvil</title><script defer src=/timer-mobile-remote.js></script><body></body></html>")
			return
		}
		if q.Method == "GET" && route == "/timer-mobile-remote.js" {
			b, _ := assets.ReadFile("assets/mobile-remote.js")
			w.Header().Set("Content-Type", "text/javascript; charset=utf-8")
			w.Write(b)
			return
		}
		if q.Method == "POST" && route == "/mobile/sync" {
			w.Header().Set("Content-Type", "application/json")
			if q.Header.Get("Origin") != "http://"+q.Host {
				http.Error(w, "{}", 403)
				return
			}
			var data struct {
				Control string         `json:"control"`
				Op      string         `json:"op"`
				Command map[string]any `json:"command"`
			}
			if e := json.NewDecoder(http.MaxBytesReader(w, q.Body, 16384)).Decode(&data); e != nil {
				http.Error(w, "{}", 400)
				return
			}
			if subtle.ConstantTimeCompare([]byte(data.Control), []byte(token)) != 1 {
				http.Error(w, "{}", 401)
				return
			}
			if data.Op == "read" {
				device := "Móvil"
				ua := q.UserAgent()
				if strings.Contains(ua, "iPhone") {
					device = "iPhone"
				} else if strings.Contains(ua, "Android") {
					device = "Android"
				} else if strings.Contains(ua, "iPad") {
					device = "iPad"
				}
				r.mobileTouch(device + " · " + host)
				json.NewEncoder(w).Encode(r.remoteRead())
				return
			}
			if data.Op == "command" {
				if e := r.remoteCommand(data.Command); e != nil {
					w.WriteHeader(400)
					json.NewEncoder(w).Encode(map[string]string{"error": e.Error()})
					return
				}
				io.WriteString(w, "{\"queued\":true}")
				return
			}
			http.Error(w, "{}", 400)
			return
		}
		if q.Method != "GET" {
			http.NotFound(w, q)
			return
		}
		key := route
		if q.URL.RawQuery != "" {
			if _, ok := snapshot[route+"?"+q.URL.RawQuery]; ok {
				key = route + "?" + q.URL.RawQuery
			}
		}
		h, ok := snapshot[key]
		if !ok {
			http.NotFound(w, q)
			return
		}
		b, e := assets.ReadFile("assets/snapshot/blobs/" + h)
		if e != nil {
			http.Error(w, "Missing resource", 500)
			return
		}
		t := mime.TypeByExtension(filepath.Ext(route))
		if strings.HasSuffix(route, ".js") {
			t = "text/javascript; charset=utf-8"
		}
		w.Header().Set("Content-Type", t)
		w.Write(b)
	})
}
