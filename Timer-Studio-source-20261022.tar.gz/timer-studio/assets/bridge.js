(function(){
 'use strict';
 if(new URLSearchParams(location.search).get('nativeSpeaker')==='1')return;
 window.EventsPROTimerDesktop=Object.freeze({version:'1.0.0',mobileURL:()=>window.timerNativeMobileURL(),mobileStatus:()=>window.timerNativeMobileStatus(),sync:p=>window.timerNativeSync(p),toggleSpeaker:()=>window.timerNativeSpeaker()});
 const click=HTMLAnchorElement.prototype.click;
 HTMLAnchorElement.prototype.click=function(){if(this.download&&this.href.startsWith('blob:')){fetch(this.href).then(r=>r.blob()).then(blob=>{const reader=new FileReader();reader.onload=()=>window.timerNativeSave(this.download,String(reader.result).split(',')[1]);reader.readAsDataURL(blob);});return;}return click.call(this);};
 const inputClick=HTMLInputElement.prototype.click;
 HTMLInputElement.prototype.click=function(){if(this.type==='file'){window.timerNativeOpen().then(file=>{if(!file)return;const bytes=Uint8Array.from(atob(file.data),c=>c.charCodeAt(0)),transfer=new DataTransfer();transfer.items.add(new File([bytes],file.name));this.files=transfer.files;this.dispatchEvent(new Event('change',{bubbles:true}));});return;}return inputClick.call(this);};
 document.addEventListener('click',e=>{const a=e.target.closest?.('a');if(a&&/^https?:/.test(a.href)&&new URL(a.href).origin!==location.origin){e.preventDefault();window.timerNativeExternal(a.href);}},true);
 const originalOpen=window.open;window.open=function(url,target,features){if(url&&/^https?:/.test(String(url))&&new URL(url,location.href).origin!==location.origin){window.timerNativeExternal(String(url));return null;}return originalOpen.call(window,url,target,features);};
})();
