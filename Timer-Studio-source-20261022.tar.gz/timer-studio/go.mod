module eventspro/timer-lightweight

go 1.25.0

require (
	github.com/jchv/go-webview2 v0.0.0-20260205173254-56598839c808
	github.com/syndtr/goleveldb v1.0.0
	github.com/webview/webview_go v0.0.0-20240831120633-6173450d4dd6
)

require (
	github.com/golang/snappy v0.0.0-20180518054509-2e65f85255db // indirect
	golang.org/x/sys v0.0.0-20210218145245-beda7e5e158e // indirect
)

replace github.com/jchv/go-webview2 => ./third_party/go-webview2
