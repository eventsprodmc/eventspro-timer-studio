package main

/*
#cgo LDFLAGS: -framework Cocoa
#include <stdlib.h>
void timerMain(void*);
int timerExternal(void*);
void timerSpeaker(void*,void*);
char* timerSave(const char*);
char* timerOpen(void);
void timerError(const char*);
*/
import "C"
import (
	webview "github.com/webview/webview_go"
	"os/exec"
	"unsafe"
)

func newView() view {
	w := webview.New(false)
	w.SetSize(1440, 1000, webview.HintNone)
	w.SetSize(800, 600, webview.HintMin)
	return w
}
func configureMain(w unsafe.Pointer)          { C.timerMain(w) }
func hasExternal(w unsafe.Pointer) bool       { return C.timerExternal(w) != 0 }
func configureSpeaker(w, main unsafe.Pointer) { C.timerSpeaker(w, main) }
func saveDialog(name string) string {
	s := C.CString(name)
	defer C.free(unsafe.Pointer(s))
	p := C.timerSave(s)
	if p == nil {
		return ""
	}
	defer C.free(unsafe.Pointer(p))
	return C.GoString(p)
}
func openDialog() string {
	p := C.timerOpen()
	if p == nil {
		return ""
	}
	defer C.free(unsafe.Pointer(p))
	return C.GoString(p)
}
func showError(s string)    { p := C.CString(s); defer C.free(unsafe.Pointer(p)); C.timerError(p) }
func openExternal(s string) { exec.Command("/usr/bin/open", s).Start() }

func toggleSpeaker(url string) map[string]any {
	if speakerView != nil {
		speakerView.Destroy()
		speakerView = nil
		return map[string]any{"open": false}
	}
	if !hasExternal(mainView.Window()) {
		return map[string]any{"open": false, "error": "single"}
	}
	speakerView = newView()
	speakerView.SetTitle("Timer Studio · Escenario")
	configureSpeaker(speakerView.Window(), mainView.Window())
	speakerView.Navigate(url)
	return map[string]any{"open": true}
}
func closeSpeaker() {
	if speakerView != nil {
		speakerView.Destroy()
		speakerView = nil
	}
}

//export timerMainClosed
func timerMainClosed() {
	if mainView != nil {
		mainView.Terminate()
	}
}
