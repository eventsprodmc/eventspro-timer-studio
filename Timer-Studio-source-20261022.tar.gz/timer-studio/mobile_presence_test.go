package main

import (
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestMobilePresenceRequiresAuthenticatedReadAndExpires(t *testing.T) {
	r, e := startReceiver(0)
	if e != nil {
		t.Fatal(e)
	}
	defer r.close()
	r.syncState(sampleState())
	h := serveTimer(r, "secret", 9140)
	request := func(token string) {
		q := httptest.NewRequest("POST", "http://127.0.0.1:9140/mobile/sync", strings.NewReader(`{"op":"read","control":"`+token+`"}`))
		q.RemoteAddr = "127.0.0.1:40000"
		q.Header.Set("Origin", "http://127.0.0.1:9140")
		q.Header.Set("User-Agent", "Mozilla/5.0 (iPhone)")
		h.ServeHTTP(httptest.NewRecorder(), q)
	}
	request("bad")
	if r.mobileStatus()["connected"] != false {
		t.Fatal("invalid token linked")
	}
	request("secret")
	s := r.mobileStatus()
	if s["connected"] != true || s["device"] != "iPhone · 127.0.0.1" {
		t.Fatal(s)
	}
	r.mu.Lock()
	r.mobileSeen = time.Now().Add(-6 * time.Second)
	r.mu.Unlock()
	if r.mobileStatus()["connected"] != false {
		t.Fatal("stale remote still linked")
	}
	request("secret")
	if r.mobileStatus()["connected"] != true {
		t.Fatal("reconnection failed")
	}
}
