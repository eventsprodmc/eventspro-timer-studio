package main

import (
	"bytes"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func sampleState() map[string]any {
	return map[string]any{"state": map[string]any{"text": "10:00", "seconds": float64(600), "mode": "down", "phase": "normal", "title": "Prueba", "message": "", "running": false}, "presets": []any{map[string]any{"id": "manuel", "name": "Manuel Gómez", "kind": "time", "day": "Día 1", "session": "Apertura"}, map[string]any{"id": "aviso", "name": "Terminar", "kind": "message", "text": "Fin"}}, "ack": []any{}}
}
func TestOSCProtocol(t *testing.T) {
	for _, c := range []struct {
		a string
		v []any
	}{{"start", nil}, {"pause", nil}, {"reset", nil}, {"duration", []any{float64(300)}}, {"mode", []any{"up"}}, {"preset", []any{"manuel"}}, {"message", []any{"Quedan preguntas"}}} {
		b := encodeOSC("/eventspro/timer/"+c.a, c.v...)
		m, e := decodeOSC(b, 0)
		if e != nil || len(m) != 1 {
			t.Fatal(e)
		}
		cmd, e := parseCommand(m[0])
		if e != nil || cmd.Action != c.a {
			t.Fatal(cmd, e)
		}
	}
	for _, b := range [][]byte{{0}, {1, 2, 3}, []byte("#bundle\x00"), append(encodeOSC("/eventspro/timer/start"), 1)} {
		if _, e := decodeOSC(b, 0); e == nil {
			t.Fatal("malformed accepted")
		}
	}
	for _, m := range []message{{"/other/start", nil}, {"/eventspro/timer/duration", []any{float64(0)}}, {"/eventspro/timer/mode", []any{"bad"}}} {
		if _, e := parseCommand(m); e == nil {
			t.Fatal("invalid command accepted")
		}
	}
}
func TestStandbyCatalogAndAcknowledgement(t *testing.T) {
	r, e := startReceiver(0)
	if e != nil {
		t.Fatal(e)
	}
	defer r.close()
	p := sampleState()
	out, e := r.syncState(p)
	if e != nil {
		t.Fatal(e)
	}
	if out["data"].(map[string]any)["companionConnected"] != false {
		t.Fatal("false connection")
	}
	remote := r.remoteRead()
	if remote["state"].(map[string]any)["running"] != false {
		t.Fatal("started automatically")
	}
	if e := r.remoteCommand(map[string]any{"action": "preset", "value": "manuel"}); e != nil {
		t.Fatal(e)
	}
	out, _ = r.syncState(p)
	q := out["data"].(map[string]any)["commands"].([]command)
	if len(q) != 1 || q[0].Action != "preset" {
		t.Fatal(q)
	}
	p["ack"] = []any{float64(q[0].ID)}
	out, _ = r.syncState(p)
	if len(out["data"].(map[string]any)["commands"].([]command)) != 0 {
		t.Fatal("ack failed")
	}
	if e := r.remoteCommand(map[string]any{"action": "preset", "value": "missing"}); e == nil {
		t.Fatal("unknown preset accepted")
	}
	if e := r.remoteCommand(map[string]any{"action": "adjust", "value": float64(100)}); e == nil {
		t.Fatal("invalid mobile adjustment")
	}
}
func TestRealUDPHandshakeAndDuration(t *testing.T) {
	r, e := startReceiver(0)
	if e != nil {
		t.Fatal(e)
	}
	defer r.close()
	r.syncState(sampleState())
	peer, e := net.DialUDP("udp4", nil, &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: r.udp.LocalAddr().(*net.UDPAddr).Port})
	if e != nil {
		t.Fatal(e)
	}
	defer peer.Close()
	peer.SetDeadline(time.Now().Add(2 * time.Second))
	peer.Write(encodeOSC("/eventspro/timer/presets"))
	buf := make([]byte, 16384)
	found := false
	for i := 0; i < 12; i++ {
		n, _, e := peer.ReadFromUDP(buf)
		if e != nil {
			t.Fatal(e)
		}
		m, e := decodeOSC(buf[:n], 0)
		if e == nil && m[0].address == "/eventspro/timer/presets/entry" {
			found = true
			break
		}
	}
	if !found {
		t.Fatal("catalog absent")
	}
	peer.Write(encodeOSC("/eventspro/timer/duration", 300))
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		out, _ := r.syncState(sampleState())
		q := out["data"].(map[string]any)["commands"].([]command)
		if len(q) == 1 {
			if q[0].Action != "duration" || q[0].Value != float64(300) {
				t.Fatal(q)
			}
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal("command not queued")
}
func TestHTTPBoundariesAndMobileToken(t *testing.T) {
	r, _ := startReceiver(0)
	defer r.close()
	r.syncState(sampleState())
	b, _ := assets.ReadFile("assets/snapshot/map.json")
	json.Unmarshal(b, &snapshot)
	h := serveTimer(r, "secret", 9140)
	run := func(method, path, body, origin, host string) *httptest.ResponseRecorder {
		q := httptest.NewRequest(method, "http://127.0.0.1:9140"+path, bytes.NewBufferString(body))
		q.RemoteAddr = "127.0.0.1:1234"
		q.Host = host
		q.Header.Set("Origin", origin)
		w := httptest.NewRecorder()
		h.ServeHTTP(w, q)
		return w
	}
	if w := run("GET", "/timer.html", "", "", "evil.invalid"); w.Code != 403 {
		t.Fatal("DNS rebinding accepted")
	}
	if w := run("GET", "/timer.html", "", "", "127.0.0.1:9140"); w.Code != 200 || !bytes.Contains(w.Body.Bytes(), []byte("Timer Studio")) {
		t.Fatal("shell failed", w.Code)
	}
	for _, c := range []struct {
		body, origin string
		status       int
	}{{`{"control":"bad","op":"read"}`, "http://127.0.0.1:9140", 401}, {`{"control":"secret","op":"read"}`, "https://other.invalid", 403}, {`{"control":"secret","op":"read"}`, "http://127.0.0.1:9140", 200}} {
		w := run("POST", "/mobile/sync", c.body, c.origin, "127.0.0.1:9140")
		if w.Code != c.status {
			t.Fatal(w.Code, c.status)
		}
	}
	q := httptest.NewRequest(http.MethodGet, "http://127.0.0.1:9140/timer.html", nil)
	q.RemoteAddr = "203.0.113.9:1"
	w := httptest.NewRecorder()
	h.ServeHTTP(w, q)
	if w.Code != 403 {
		t.Fatal("foreign peer accepted")
	}
}
func TestSnapshotContainsOnlyTimer(t *testing.T) {
	b, _ := assets.ReadFile("assets/snapshot/map.json")
	var m map[string]string
	json.Unmarshal(b, &m)
	if len(m) != 22 {
		t.Fatal(len(m))
	}
	for url, hash := range m {
		for _, bad := range []string{"catalog", "manual", "lighting-visuals", "suite-dicolor", ".pdf"} {
			if bytes.Contains([]byte(url), []byte(bad)) {
				t.Fatal(url)
			}
		}
		f, e := assets.Open("assets/snapshot/blobs/" + hash)
		if e != nil {
			t.Fatal(e)
		}
		b, _ := io.ReadAll(f)
		f.Close()
		limit := 100000
		if url == "/timer-mobile-remote.js" {
			limit = 300000
		} // Includes the offline QR decoder.
		if len(b) > limit {
			t.Fatal("unexpected large resource", url, len(b))
		}
	}
}

func TestLegacyAccents(t *testing.T) {
	if s := decodeStorage([]byte{1, 'i', 'n', 't', 'e', 'r', 'v', 'e', 'n', 'c', 'i', 0xf3, 'n'}); s != "intervención" {
		t.Fatal(s)
	}
	if s := decodeStorage([]byte{0, 'G', 0, 0xf3, 0, 'm', 0, 'e', 0, 'z', 0}); s != "Gómez" {
		t.Fatal(s)
	}
}
