package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net"
	"strings"
	"sync"
	"time"
)

type command struct {
	Action  string `json:"action"`
	Value   any    `json:"value,omitempty"`
	ID      int    `json:"id"`
	expires time.Time
}
type receiver struct {
	mu           sync.Mutex
	udp          *net.UDPConn
	peer         *net.UDPAddr
	seen, synced time.Time
	mobileSeen   time.Time
	mobileDevice string
	seq          int
	queue        []command
	catalog      []map[string]any
	revision     string
	state        map[string]any
	done         chan struct{}
}

func localPeer(ip net.IP) bool {
	if ip.IsLoopback() {
		return true
	}
	addrs, _ := net.InterfaceAddrs()
	for _, a := range addrs {
		if n, ok := a.(*net.IPNet); ok && n.Contains(ip) {
			return true
		}
	}
	return false
}
func oscString(s string) []byte {
	b := append([]byte(s), 0)
	for len(b)%4 != 0 {
		b = append(b, 0)
	}
	return b
}
func encodeOSC(address string, args ...any) []byte {
	tags := ","
	var payload []byte
	for _, v := range args {
		switch x := v.(type) {
		case string:
			tags += "s"
			payload = append(payload, oscString(x)...)
		case bool:
			tags += "i"
			var n int32
			if x {
				n = 1
			}
			payload = binary.BigEndian.AppendUint32(payload, uint32(n))
		case int:
			tags += "i"
			payload = binary.BigEndian.AppendUint32(payload, uint32(int32(x)))
		case float64:
			tags += "i"
			payload = binary.BigEndian.AppendUint32(payload, uint32(int32(x)))
		default:
			tags += "s"
			payload = append(payload, oscString(fmt.Sprint(x))...)
		}
	}
	return append(append(oscString(address), oscString(tags)...), payload...)
}

type message struct {
	address string
	args    []any
}

func decodeOSC(b []byte, depth int) ([]message, error) {
	if depth > 4 || len(b) > 16384 {
		return nil, errors.New("Invalid OSC packet")
	}
	if bytes.HasPrefix(b, []byte("#bundle\x00")) {
		if len(b) < 16 {
			return nil, errors.New("Invalid bundle")
		}
		var all []message
		for pos := 16; pos < len(b); {
			if pos+4 > len(b) {
				return nil, errors.New("Invalid bundle")
			}
			n := int(binary.BigEndian.Uint32(b[pos:]))
			pos += 4
			if n < 1 || pos+n > len(b) {
				return nil, errors.New("Invalid bundle")
			}
			m, e := decodeOSC(b[pos:pos+n], depth+1)
			if e != nil {
				return nil, e
			}
			all = append(all, m...)
			if len(all) > 32 {
				return nil, errors.New("Too many commands")
			}
			pos += n
		}
		return all, nil
	}
	pos := 0
	read := func() (string, error) {
		if pos >= len(b) {
			return "", errors.New("Invalid string")
		}
		i := bytes.IndexByte(b[pos:], 0)
		if i < 0 {
			return "", errors.New("Invalid string")
		}
		s := string(b[pos : pos+i])
		pos += (i + 4) / 4 * 4
		if pos > len(b) {
			return "", errors.New("Invalid string")
		}
		return s, nil
	}
	a, e := read()
	if e != nil {
		return nil, e
	}
	tags, e := read()
	if e != nil || !strings.HasPrefix(tags, ",") {
		return nil, errors.New("Invalid tags")
	}
	m := message{address: a}
	for _, t := range tags[1:] {
		switch t {
		case 's':
			s, e := read()
			if e != nil {
				return nil, e
			}
			m.args = append(m.args, s)
		case 'i', 'f':
			if pos+4 > len(b) {
				return nil, errors.New("Invalid number")
			}
			n := binary.BigEndian.Uint32(b[pos:])
			pos += 4
			if t == 'i' {
				m.args = append(m.args, float64(int32(n)))
			} else {
				m.args = append(m.args, float64(math.Float32frombits(n)))
			}
		default:
			return nil, errors.New("Unsupported OSC type")
		}
	}
	if pos != len(b) {
		return nil, errors.New("Trailing OSC data")
	}
	return []message{m}, nil
}
func parseCommand(m message) (command, error) {
	const prefix = "/eventspro/timer/"
	c := command{Action: strings.TrimPrefix(m.address, prefix)}
	if !strings.HasPrefix(m.address, prefix) {
		return c, errors.New("Unknown path")
	}
	if len(m.args) == 0 {
		switch c.Action {
		case "start", "pause", "reset", "message/clear", "lap":
			return c, nil
		}
	}
	if len(m.args) == 1 {
		c.Value = m.args[0]
		switch c.Action {
		case "duration", "adjust":
			if n, ok := c.Value.(float64); ok && math.Trunc(n) == n && math.Abs(n) <= 86400 && (c.Action != "duration" || n >= 1) {
				return c, nil
			}
		case "message", "title", "preset", "preset/start", "message/preset":
			if s, ok := c.Value.(string); ok {
				limit := 100
				if c.Action == "message" {
					limit = 160
				}
				if len([]rune(s)) <= limit && (c.Action != "message/preset" || len(s) > 0) {
					return c, nil
				}
			}
		case "mode":
			if s, ok := c.Value.(string); ok && (s == "down" || s == "up" || s == "clock") {
				return c, nil
			}
		}
	}
	return c, errors.New("Invalid command")
}
func startReceiver(port int) (*receiver, error) {
	u, e := net.ListenUDP("udp4", &net.UDPAddr{Port: port})
	if e != nil {
		return nil, e
	}
	r := &receiver{udp: u, revision: "empty", done: make(chan struct{})}
	go r.read()
	go func() {
		t := time.NewTicker(500 * time.Millisecond)
		defer t.Stop()
		for {
			select {
			case <-t.C:
				r.mu.Lock()
				r.feedback()
				r.mu.Unlock()
			case <-r.done:
				return
			}
		}
	}()
	return r, nil
}
func (r *receiver) close()       { close(r.done); r.udp.Close() }
func (r *receiver) active() bool { return !r.seen.IsZero() && time.Since(r.seen) < 15*time.Second }
func (r *receiver) send(key string, args ...any) {
	if r.peer != nil && r.active() {
		r.udp.WriteToUDP(encodeOSC("/eventspro/timer/"+key, args...), r.peer)
	}
}
func (r *receiver) sendCatalog() {
	r.send("presets/begin", r.revision, len(r.catalog))
	for _, p := range r.catalog {
		b, _ := json.Marshal(p)
		r.send("presets/entry", r.revision, string(b))
	}
	r.send("presets/end", r.revision)
}
func (r *receiver) feedback() {
	ok := r.state != nil && time.Since(r.synced) < 5*time.Second
	r.send("connected", ok)
	if ok {
		for k, v := range r.state {
			r.send(k, v)
		}
	}
}
func (r *receiver) read() {
	b := make([]byte, 16385)
	for {
		n, p, e := r.udp.ReadFromUDP(b)
		if e != nil {
			return
		}
		if n > 16384 {
			continue
		}
		m, e := decodeOSC(b[:n], 0)
		if e != nil {
			continue
		}
		r.mu.Lock()
		hello := len(m) == 1 && m[0].address == "/eventspro/timer/presets" && len(m[0].args) == 0
		if !r.active() {
			if !hello || !localPeer(p.IP) {
				r.mu.Unlock()
				continue
			}
			r.peer = p
		} else if !p.IP.Equal(r.peer.IP) || p.Port != r.peer.Port {
			r.mu.Unlock()
			continue
		}
		if hello {
			r.seen = time.Now()
			r.sendCatalog()
			r.feedback()
			r.mu.Unlock()
			continue
		}
		var q []command
		for _, msg := range m {
			c, err := parseCommand(msg)
			if err != nil {
				e = err
				break
			}
			q = append(q, c)
		}
		if e == nil && (len(q) == 0 || len(q) > 32 || len(q)+len(r.queue) > 64) {
			e = errors.New("Too many commands")
		}
		if e == nil {
			r.seen = time.Now()
			if r.state == nil || time.Since(r.synced) >= 5*time.Second {
				e = errors.New("Timer is not ready")
			}
		}
		if e != nil {
			r.send("error", e.Error())
		} else {
			for _, c := range q {
				r.seq++
				c.ID = r.seq
				c.expires = time.Now().Add(5 * time.Second)
				r.queue = append(r.queue, c)
			}
		}
		r.mu.Unlock()
	}
}
func (r *receiver) syncState(payload map[string]any) (map[string]any, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	raw, _ := json.Marshal(payload)
	if len(raw) > 131072 {
		return nil, errors.New("Invalid state")
	}
	s, ok := payload["state"].(map[string]any)
	if !ok {
		return nil, errors.New("Invalid state")
	}
	text, ok := s["text"].(string)
	seconds, num := s["seconds"].(float64)
	mode, _ := s["mode"].(string)
	phase, _ := s["phase"].(string)
	title, tok := s["title"].(string)
	msg, mok := s["message"].(string)
	running, bok := s["running"].(bool)
	if !ok || !num || math.Abs(seconds) > 1e9 || len(text) > 32 || !strings.Contains("|down|up|clock|", "|"+mode+"|") || !strings.Contains("|normal|warning|critical|over|clock|", "|"+phase+"|") || !tok || !mok || !bok || len([]rune(title)) > 160 || len([]rune(msg)) > 160 {
		return nil, errors.New("Invalid Timer state")
	}
	presets, ok := payload["presets"].([]any)
	if !ok || len(presets) > 230 {
		return nil, errors.New("Invalid agenda")
	}
	next := []map[string]any{}
	ids := map[string]bool{}
	times, messages := 0, 0
	for _, raw := range presets {
		p, ok := raw.(map[string]any)
		if !ok {
			return nil, errors.New("Invalid preset")
		}
		id, iok := p["id"].(string)
		name, nok := p["name"].(string)
		if !iok || !nok || id == "" || name == "" || len([]rune(id)) > 100 || len([]rune(name)) > 100 || ids[id] {
			return nil, errors.New("Invalid preset")
		}
		ids[id] = true
		n := map[string]any{"id": id, "name": name}
		if p["kind"] == "message" {
			messages++
			v, ok := p["text"].(string)
			if !ok || len([]rune(v)) > 160 || messages > 30 {
				return nil, errors.New("Invalid message")
			}
			n["kind"] = "message"
			n["text"] = v
		} else {
			times++
			if times > 200 || (p["kind"] != nil && p["kind"] != "time") {
				return nil, errors.New("Invalid preset")
			}
			n["kind"] = "time"
			for _, k := range []string{"day", "session"} {
				v, _ := p[k].(string)
				limit := 60
				if k == "session" {
					limit = 80
				}
				runes := []rune(v)
				if len(runes) > limit {
					runes = runes[:limit]
				}
				n[k] = string(runes)
			}
		}
		next = append(next, n)
	}
	r.state = map[string]any{"time": text, "remaining": seconds, "phase": phase, "running": running, "title": title, "mode": mode, "message": msg}
	r.synced = time.Now()
	b, _ := json.Marshal(next)
	h := sha256.Sum256(b)
	rev := hex.EncodeToString(h[:])[:16]
	if rev != r.revision {
		r.catalog = next
		r.revision = rev
		r.sendCatalog()
	}
	ack := map[int]bool{}
	if a, ok := payload["ack"].([]any); ok {
		for _, v := range a {
			if n, ok := v.(float64); ok {
				ack[int(n)] = true
			}
		}
	}
	q := []command{}
	for _, c := range r.queue {
		if c.expires.After(time.Now()) && !ack[c.ID] {
			q = append(q, c)
		}
	}
	r.queue = q
	if errs, ok := payload["errors"].([]any); ok {
		for i, e := range errs {
			if i >= 10 {
				break
			}
			v := []rune(fmt.Sprint(e))
			if len(v) > 160 {
				v = v[:160]
			}
			r.send("error", string(v))
		}
	}
	host := ""
	if r.peer != nil {
		host = r.peer.IP.String()
	}
	return map[string]any{"status": 200, "data": map[string]any{"commands": q, "companionConnected": r.active(), "mobileConnected": time.Since(r.mobileSeen) < 5*time.Second, "mobileDevice": r.mobileDevice, "settings": map[string]any{"feedbackHost": host, "oscPort": r.udp.LocalAddr().(*net.UDPAddr).Port}, "error": ""}}, nil
}
func (r *receiver) remoteRead() map[string]any {
	r.mu.Lock()
	defer r.mu.Unlock()
	var state map[string]any
	if r.state != nil {
		state = map[string]any{}
		for k, v := range r.state {
			state[k] = v
		}
		state["text"] = state["time"]
	}
	ps := []map[string]any{}
	ms := []map[string]any{}
	for _, p := range r.catalog {
		if p["kind"] == "message" {
			ms = append(ms, map[string]any{"id": p["id"], "name": p["name"]})
		} else {
			ps = append(ps, p)
		}
	}
	return map[string]any{"online": r.state != nil && time.Since(r.synced) < 5*time.Second, "state": state, "presets": ps, "messages": ms}
}
func (r *receiver) remoteCommand(input map[string]any) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.state == nil || time.Since(r.synced) >= 5*time.Second {
		return errors.New("Timer disconnected")
	}
	action, _ := input["action"].(string)
	args := []any{}
	if v, ok := input["value"]; ok {
		args = append(args, v)
	}
	c, e := parseCommand(message{"/eventspro/timer/" + action, args})
	if e != nil {
		return e
	}
	allowed := map[string]bool{"start": true, "pause": true, "reset": true, "message/clear": true, "adjust": true, "preset": true, "message/preset": true, "mode": true}
	if !allowed[c.Action] {
		return errors.New("Command rejected")
	}
	if c.Action == "adjust" && c.Value != float64(-60) && c.Value != float64(60) {
		return errors.New("Command rejected")
	}
	if c.Action == "preset" || c.Action == "message/preset" {
		found := false
		for _, p := range r.catalog {
			if p["id"] == c.Value && ((c.Action == "preset" && p["kind"] != "message") || (c.Action == "message/preset" && p["kind"] == "message")) {
				found = true
			}
		}
		if !found {
			return errors.New("Unknown preset")
		}
	}
	q := []command{}
	for _, v := range r.queue {
		if v.expires.After(time.Now()) {
			q = append(q, v)
		}
	}
	if len(q) >= 32 {
		return errors.New("Queue full")
	}
	r.seq++
	c.ID = r.seq
	c.expires = time.Now().Add(5 * time.Second)
	r.queue = append(q, c)
	return nil
}

func (r *receiver) mobileTouch(device string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.mobileSeen = time.Now()
	r.mobileDevice = device
}
func (r *receiver) mobileStatus() map[string]any {
	r.mu.Lock()
	defer r.mu.Unlock()
	return map[string]any{"connected": time.Since(r.mobileSeen) < 5*time.Second, "device": r.mobileDevice}
}
