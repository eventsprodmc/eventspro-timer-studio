# Timer por red local

Candidato de pruebas, no entrega verificada en oficina.

1. Importa este módulo en Companion y selecciona Timer en navegador por red local.
2. En Windows abre http://IP-DE-COMPANION:8000/instance/NOMBRE-DE-LA-CONEXION/index.html. Sustituye la IP y el nombre exacto de la conexión; los espacios del nombre se escriben como %20.
3. En Presets arrastra Iniciar, Pausa, Reset y los tiempos de 5, 10 y 30 minutos.
4. En Timer pulsa Control móvil y escanea el QR con la cámara nativa del teléfono. Ambos equipos deben alcanzar la misma red local. No se usa la cámara del ordenador.
5. Abre la vista extendida desde Timer y desplázala a la pantalla del ponente.

El módulo incluye los recursos de Timer y mantiene su reloj en Companion. No necesita internet durante la sesión. El ordenador de Companion debe permanecer encendido y accesible. No se ha comprobado todavía en una red física con Windows y teléfono reales. Esta versión no conserva el estado del reloj al reiniciar el módulo; la agenda continúa guardada en el navegador de Timer.

La opción Timer instalado (OSC) conserva la comunicación anterior. No sustituye la aplicación de Mac ni cambia el resto de la suite.
