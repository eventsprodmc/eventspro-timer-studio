# EventsPRO - ToolsPRO Timer Studio

## Español
1. En Companion 5.1, importa el paquete .tgz en Modules → Import module package y añade EventsPRO: ToolsPRO Timer Studio.
2. Inicia el conector Timer OSC 1.4 en el equipo de Timer y abre Timer. El enlace se realiza automáticamente; no hay código, botón Conectar ni ventana auxiliar.
3. Configura la IP del equipo Timer en la conexión de Companion. En el mismo equipo usa 127.0.0.1 y puerto OSC 9010. Los ajustes de retorno están plegados en Avanzados.
4. Para obtener todas las páginas de días, sesiones, ponentes y avisos, descarga la [botonera de la agenda](http://127.0.0.1:9140/agenda.companionconfig) con Timer abierto y una agenda guardada. Desde otro equipo, sustituye 127.0.0.1 por la IP del equipo Timer. En Companion abre Import / Export e importa el archivo una vez, remapeando la conexión a ToolsPRO_Timer. Haz una copia de Companion antes: la importación completa puede reemplazar páginas seleccionadas; no fusiona automáticamente tus páginas existentes. Revisa los destinos y conserva las demás secciones de configuración.
5. En Presets arrastra los botones de Control Timer y Modo. Cada categoría de día/sesión contiene un único botón por ponente. Ese botón prepara el tiempo en STANDBY, sin arrancar. Solo INICIAR (Play) lanza el contador. Pausa antes de cargar otra intervención o cambiar de modo.
6. Avisos muestra los mensajes guardados en Timer. Pulsar un aviso lo envía al ponente; AVISO con la cruz lo retira.

El botón de tiempo muestra el valor real y las fases verde, amarillo y rojo. Modo incluye Cuenta atrás, Cronómetro y Reloj con selección activa. Hasta 200 intervenciones y 30 avisos. La agenda y los mensajes permanecen en el navegador Timer y no se borran al desconectar.

Para equipos separados, configura el conector para recibir OSC en la IP del equipo Timer y devolver estado a la IP de Companion; configura la interfaz receptora de Companion en Avanzados. Consulta README del conector. No uses la misma recepción de retorno a la vez con OSC Generic.

Este paquete se importa manualmente. No está publicado en el catálogo oficial de Bitfocus.

## English
1. In Companion 5.1, import the .tgz with Modules → Import module package and add EventsPRO: ToolsPRO Timer Studio.
2. Start Timer OSC connector 1.4 on the Timer computer and open Timer. It links automatically; there is no code, Connect button or auxiliary window.
3. Set the Timer computer IP in the Companion connection. On the same computer use 127.0.0.1 and OSC port 9010. Feedback settings are folded under Advanced.
4. To obtain all day, session, speaker and message pages, download the [agenda button pages](http://127.0.0.1:9140/agenda.companionconfig?language=en) while Timer is open with a saved agenda. From another computer, replace 127.0.0.1 with the Timer computer IP. In Companion, open Import / Export and import the file once, remapping its connection to ToolsPRO_Timer. Back up Companion first: a full import can replace selected pages; it does not automatically merge existing pages. Review page destinations and preserve other configuration sections.
5. Under Presets, drag Timer control and Mode buttons. Each day/session category contains one button per speaker. It prepares the time in STANDBY without starting. Only START (Play) launches the timer. Pause before loading a different speaker or changing mode.
6. Messages lists saved Timer messages. Pressing one sends it to the speaker; CLEAR removes it.

The time button shows the live value and green, yellow and red phases. Mode includes Countdown, Stopwatch and Clock with active selection. Up to 200 speaker slots and 30 messages. Disconnecting does not remove the browser agenda or messages.

For separate computers, configure the connector to receive OSC on the Timer computer IP and return state to the Companion IP; configure the Companion receiving interface under Advanced. See the connector README. Do not share the same feedback receive port with OSC Generic.

This package is imported manually. It is not listed in the official Bitfocus catalogue.
