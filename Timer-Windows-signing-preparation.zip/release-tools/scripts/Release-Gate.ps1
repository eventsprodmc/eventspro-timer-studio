[CmdletBinding()]
param([Parameter(Mandatory)][string]$Installer,[Parameter(Mandatory)][string]$App,[Parameter(Mandatory)][string]$Uninstaller,[Parameter(Mandatory)][string]$ExpectedPublisher,[Parameter(Mandatory)][string]$Evidence,[Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
& "$PSScriptRoot/Verify-Signatures.ps1" -Files @($Installer,$App,$Uninstaller) -ExpectedPublisher $ExpectedPublisher
$hash=(Get-FileHash -LiteralPath $Installer -Algorithm SHA256).Hash.ToLower()
$e=Get-Content -LiteralPath $Evidence -Raw|ConvertFrom-Json
if($e.installerSHA256 -cne $hash){throw 'Office evidence does not match this exact installer'}
if(!$e.windowsVersion -or !$e.tester -or !$e.testedAt -or !$e.evidenceDirectory){throw 'Windows test identification/evidence required'}
foreach($name in @('chromeDownload','defenderScan','smartScreenLaunch','installation','approvedIcon','qrPhonePairing','remoteControl','companionOSC','extendedDisplay','internetDisconnected','uninstallation')){
 if($e.checks.$name -cne 'passed'){throw "Windows check pending or failed: $name"}
}
if(Test-Path -LiteralPath $OutputDirectory){throw 'Choose a new staging directory; existing releases are preserved'}
New-Item -ItemType Directory -Path $OutputDirectory|Out-Null
Copy-Item -LiteralPath $Installer -Destination (Join-Path $OutputDirectory 'Timer-Studio-Windows.exe')
Copy-Item -LiteralPath $Evidence -Destination (Join-Path $OutputDirectory 'windows-test-evidence.json')
@{installerSHA256=$hash;publisher=$ExpectedPublisher;sourceCommit=$e.sourceCommit;testedAt=$e.testedAt}|ConvertTo-Json|Set-Content (Join-Path $OutputDirectory 'release-manifest.json')
Write-Output 'Windows release staged for publication; hosting has not been changed.'
