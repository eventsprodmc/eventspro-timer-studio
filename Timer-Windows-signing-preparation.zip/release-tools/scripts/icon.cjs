const fs=require('fs'),path=require('path');
(async()=>{
const [input,output]=process.argv.slice(2);if(!input||!output||fs.existsSync(output))throw Error('New input/output paths required');
const PE=await require('pe-library/cjs').load(),RE=await require('resedit/cjs').load();
const exe=PE.NtExecutable.from(fs.readFileSync(input)),res=PE.NtExecutableResource.from(exe);
const icon=RE.Data.IconFile.from(fs.readFileSync(path.join(__dirname,'../packaging/timer.ico')));
RE.Resource.IconGroupEntry.replaceIconsForResource(res.entries,1,1033,icon.icons.map(i=>i.data));
RE.Resource.VersionInfo.create(1033,{fileVersionMS:65536,productVersionMS:65536,fileOS:0x40004,fileType:1},[{lang:1033,codepage:1200,values:{CompanyName:'EVENTSPRO DMC SL',FileDescription:'EventsPRO Timer Studio',FileVersion:'1.0.0',ProductName:'Timer Studio',ProductVersion:'1.0.0',OriginalFilename:'Timer Studio.exe'}}]).outputToResourceEntries(res.entries);
res.outputResource(exe);fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,Buffer.from(exe.generate()));
const check=PE.NtExecutableResource.from(PE.NtExecutable.from(fs.readFileSync(output)));
if(check.entries.filter(e=>e.type===3).length!==icon.icons.length)throw Error('Icon resource count mismatch');
console.log('Approved icon and Windows metadata verified');
})();
