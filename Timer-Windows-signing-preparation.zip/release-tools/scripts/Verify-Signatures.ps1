[CmdletBinding()]
param([Parameter(Mandatory)][string[]]$Files,[Parameter(Mandatory)][string]$ExpectedPublisher)
$ErrorActionPreference='Stop'
foreach($file in $Files){
  if(!(Test-Path -LiteralPath $file)){throw "Missing signed file: $file"}
  $sig=Get-AuthenticodeSignature -LiteralPath $file
  if($sig.Status -ne 'Valid'){throw "Invalid signature: $file ($($sig.Status))"}
  if(!$sig.SignerCertificate -or $sig.SignerCertificate.Subject -ne $ExpectedPublisher){throw "Unexpected publisher: $file"}
  if(!$sig.TimeStamperCertificate){throw "Missing timestamp: $file"}
}
Write-Output 'Signature, publisher and timestamp verified. Windows user acceptance remains pending.'
