!ifndef PAYLOAD
!error "PAYLOAD required"
!endif
!ifdef EXPORT_UNINSTALLER
!uninstfinalize `powershell.exe -NoProfile -NonInteractive -Command "Copy-Item -LiteralPath '%1' -Destination '${UNINSTALLER_PATH}' -Force -ErrorAction Stop"` = 0
!else
!ifndef SIGNED_UNINSTALLER
!error "Signed uninstaller required"
!endif
!uninstfinalize `powershell.exe -NoProfile -NonInteractive -Command "Copy-Item -LiteralPath '${SIGNED_UNINSTALLER}' -Destination '%1' -Force -ErrorAction Stop"` = 0
!endif
Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"
Name "Timer Studio"
OutFile "${OUTPUT_INSTALLER}"
InstallDir "$LOCALAPPDATA\Programs\EventsPRO\Timer Studio"
RequestExecutionLevel user
SetCompressor /SOLID lzma
SetCompressorDictSize 32
BrandingText "EventsPRO"
!define MUI_ICON "${TIMER_ICON}"
!define MUI_UNICON "${TIMER_ICON}"
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN "$INSTDIR\Timer Studio.exe"
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Spanish"
!insertmacro MUI_LANGUAGE "English"
VIProductVersion "1.0.0.0"
VIAddVersionKey /LANG=1033 "ProductName" "Timer Studio"
VIAddVersionKey /LANG=1033 "FileDescription" "EventsPRO Timer Studio Installer"
VIAddVersionKey /LANG=1033 "CompanyName" "EventsPRO"
VIAddVersionKey /LANG=1033 "FileVersion" "1.0.0"
VIAddVersionKey /LANG=1033 "LegalCopyright" "EventsPRO"
Function ReadWebView
ReadRegStr $0 HKLM "SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" "pv"
${If} $0 == ""
ReadRegStr $0 HKCU "Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" "pv"
${EndIf}
FunctionEnd
Section "Timer Studio"
FindWindow $0 "" "Timer Studio · Tools EventsPRO"
${If} $0 != 0
MessageBox MB_ICONSTOP "Cierra Timer antes de actualizar."
Abort
${EndIf}
Call ReadWebView
${If} $0 == ""
MessageBox MB_ICONSTOP "Falta Microsoft Edge WebView2 Runtime. Instálalo antes de usar Timer sin internet."
Abort
${EndIf}
CreateDirectory "$INSTDIR"
IfFileExists "$INSTDIR\Timer Studio.exe" 0 install
System::Call 'kernel32::GetTickCount() i.r0'
backup:
IfFileExists "$INSTDIR\Timer Studio-$0.backup.exe" 0 copybackup
IntOp $0 $0 + 1
Goto backup
copybackup:
ClearErrors
CopyFiles /SILENT "$INSTDIR\Timer Studio.exe" "$INSTDIR\Timer Studio-$0.backup.exe"
IfErrors 0 install
MessageBox MB_ICONSTOP "No se ha podido conservar la versión anterior. Cierra Timer y vuelve a intentarlo."
Abort
install:
SetOutPath "$INSTDIR"
File "${PAYLOAD}\Timer Studio.exe"
File "${PAYLOAD}\Third-Party-Notices.txt"
File "${PAYLOAD}\WebView2Loader.dll"
File "${PAYLOAD}\jsQR-LICENSE.txt"
File "${PAYLOAD}\WebView2-LICENSE.txt"
CreateDirectory "$SMPROGRAMS\EventsPRO"
CreateShortcut "$SMPROGRAMS\EventsPRO\Timer Studio.lnk" "$INSTDIR\Timer Studio.exe"
CreateShortcut "$DESKTOP\Timer Studio.lnk" "$INSTDIR\Timer Studio.exe"
WriteUninstaller "$INSTDIR\Uninstall.exe"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EventsPROTimerStudio" "DisplayName" "Timer Studio"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EventsPROTimerStudio" "DisplayIcon" "$INSTDIR\Timer Studio.exe"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EventsPROTimerStudio" "UninstallString" '"$INSTDIR\Uninstall.exe"'
SectionEnd
Section "Uninstall"
Delete "$SMPROGRAMS\EventsPRO\Timer Studio.lnk"
Delete "$DESKTOP\Timer Studio.lnk"
DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EventsPROTimerStudio"
RMDir /r "$INSTDIR"
SectionEnd
