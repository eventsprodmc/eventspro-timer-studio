# Timer Windows signing preparation

Status: prepared, not signed, not publicly distributed. No Mac or suite files are changed.

## Activation after SignPath approval

Place this kit at `release-tools/` in the Timer-only repository. Copy `workflow/sign-windows.yml.template` to `.github/workflows/sign-windows.yml` only after approval and configuration. The workflow is manually dispatched and does not publish to hosting.

Configure the SignPath GitHub integration for **eventsprodmc/eventspro-timer-studio only**, not other repositories. SignPath account MFA, reviewer/approver roles and any required permissions still need confirmation. Never put API credentials in source or messages.

Required GitHub secret: SIGNPATH_API_TOKEN. Required variables: SIGNPATH_ORGANIZATION_ID, SIGNPATH_PROJECT_SLUG, SIGNPATH_POLICY_SLUG, SIGNPATH_PUBLISHER_SUBJECT and SIGNPATH_APP_CONFIGURATION, SIGNPATH_UNINSTALLER_CONFIGURATION, SIGNPATH_INSTALLER_CONFIGURATION. Values must come from the approved account; none are invented here. Each configuration must match the ZIP artifact filename. Use a production signing policy with manual approval. Pin action commits and tool versions during approved integration review.

The pipeline signs the app, generates/signs the NSIS uninstaller, embeds the signed uninstaller, signs the final installer, then verifies trust, exact publisher and timestamp. It must be exercised against the approved service before being called operational. A failed or incomplete signature stops the process. It never signs Microsoft DLLs under our identity.

## Office acceptance

Complete windows-evidence.template.json with results on actual Windows and the exact final installer SHA256. Test Chrome download, Defender scan, SmartScreen launch, installation, approved icon, QR from PC scanned by phone, remote control, Companion OSC, extended display, unplugged internet and uninstall. Archive screenshots/logs and Windows version. Backend tests on a hosted Windows runner do not replace these checks.

Release-Gate.ps1 stages a new Windows-only download only when signature checks and every Windows acceptance check pass. It does not upload. Before hosting publication, back up the existing Windows file, upload the new signed binary to a new Windows-only URL, verify public SHA256 and Content-Type, then update only the Windows download target. Preserve the Mac URL, suite HTML, suite version and offline manifest unless a separately reviewed targeted change is necessary. Public download must be tested again in Chrome on Windows. Retain rollback originals.

WebView2 Runtime must already be installed for an offline installation. The runtime is not bundled to keep Timer small. Prepare the official offline Runtime separately for office machines that lack it; do not claim an internet-free first installation on such machines.

SignPath approval, production certificate subject, installed GitHub app permissions, actual signing, installer operation and consumer Windows acceptance remain pending.

References: https://docs.signpath.io/trusted-build-systems/github ; https://signpath.org/terms.html
